public class AppUsingFinalClass {

    public static void main(String[] args) {
        new FinalClass().callMe();
    }

}
