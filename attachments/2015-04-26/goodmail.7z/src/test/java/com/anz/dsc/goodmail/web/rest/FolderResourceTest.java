package com.anz.dsc.goodmail.web.rest;

import com.anz.dsc.goodmail.Application;
import com.anz.dsc.goodmail.domain.Folder;
import com.anz.dsc.goodmail.repository.FolderRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the FolderResource REST controller.
 *
 * @see FolderResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
@IntegrationTest
public class FolderResourceTest {

    private static final String DEFAULT_FOLDER_ID = "SAMPLE_TEXT";
    private static final String UPDATED_FOLDER_ID = "UPDATED_TEXT";
    private static final String DEFAULT_ADDRESS = "SAMPLE_TEXT";
    private static final String UPDATED_ADDRESS = "UPDATED_TEXT";

    private static final Boolean DEFAULT_ACTIVE = false;
    private static final Boolean UPDATED_ACTIVE = true;

    private static final Integer DEFAULT_WEIGHT = 0;
    private static final Integer UPDATED_WEIGHT = 1;

    private static final Long DEFAULT_CAPACITY = 0L;
    private static final Long UPDATED_CAPACITY = 1L;

    private static final Integer DEFAULT_THRESHOLD = 50;
    private static final Integer UPDATED_THRESHOLD = 51;
    private static final String DEFAULT_USERNAME = "SAMPLE_TEXT";
    private static final String UPDATED_USERNAME = "UPDATED_TEXT";
    private static final String DEFAULT_PASSWORD = "SAMPLE_TEXT";
    private static final String UPDATED_PASSWORD = "UPDATED_TEXT";

    @Inject
    private FolderRepository folderRepository;

    private MockMvc restFolderMockMvc;

    private Folder folder;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        FolderResource folderResource = new FolderResource();
        ReflectionTestUtils.setField(folderResource, "folderRepository", folderRepository);
        this.restFolderMockMvc = MockMvcBuilders.standaloneSetup(folderResource).build();
    }

    @Before
    public void initTest() {
        folder = new Folder();
        folder.setFolderId(DEFAULT_FOLDER_ID);
        folder.setAddress(DEFAULT_ADDRESS);
        folder.setActive(DEFAULT_ACTIVE);
        folder.setWeight(DEFAULT_WEIGHT);
        folder.setCapacity(DEFAULT_CAPACITY);
        folder.setThreshold(DEFAULT_THRESHOLD);
        folder.setUserName(DEFAULT_USERNAME);
        folder.setPassword(DEFAULT_PASSWORD);
    }

    @Test
    @Transactional
    public void createFolder() throws Exception {
        int databaseSizeBeforeCreate = folderRepository.findAll().size();

        // Create the Folder
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isCreated());

        // Validate the Folder in the database
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(databaseSizeBeforeCreate + 1);
        Folder testFolder = folders.get(folders.size() - 1);
        assertThat(testFolder.getFolderId()).isEqualTo(DEFAULT_FOLDER_ID);
        assertThat(testFolder.getAddress()).isEqualTo(DEFAULT_ADDRESS);
        assertThat(testFolder.getActive()).isEqualTo(DEFAULT_ACTIVE);
        assertThat(testFolder.getWeight()).isEqualTo(DEFAULT_WEIGHT);
        assertThat(testFolder.getCapacity()).isEqualTo(DEFAULT_CAPACITY);
        assertThat(testFolder.getThreshold()).isEqualTo(DEFAULT_THRESHOLD);
        assertThat(testFolder.getUserName()).isEqualTo(DEFAULT_USERNAME);
        assertThat(testFolder.getPassword()).isEqualTo(DEFAULT_PASSWORD);
    }

    @Test
    @Transactional
    public void checkFolderIdIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setFolderId(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkAddressIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setAddress(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkWeightIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setWeight(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkCapacityIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setCapacity(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkThresholdIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setThreshold(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkUserNameIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setUserName(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void checkPasswordIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(folderRepository.findAll()).hasSize(0);
        // set the field null
        folder.setPassword(null);

        // Create the Folder, which fails.
        restFolderMockMvc.perform(post("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(0);
    }

    @Test
    @Transactional
    public void getAllFolders() throws Exception {
        // Initialize the database
        folderRepository.saveAndFlush(folder);

        // Get all the folders
        restFolderMockMvc.perform(get("/api/folders"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(folder.getId().intValue())))
                .andExpect(jsonPath("$.[*].folderId").value(hasItem(DEFAULT_FOLDER_ID.toString())))
                .andExpect(jsonPath("$.[*].address").value(hasItem(DEFAULT_ADDRESS.toString())))
                .andExpect(jsonPath("$.[*].active").value(hasItem(DEFAULT_ACTIVE.booleanValue())))
                .andExpect(jsonPath("$.[*].weight").value(hasItem(DEFAULT_WEIGHT)))
                .andExpect(jsonPath("$.[*].capacity").value(hasItem(DEFAULT_CAPACITY.intValue())))
                .andExpect(jsonPath("$.[*].threshold").value(hasItem(DEFAULT_THRESHOLD)))
                .andExpect(jsonPath("$.[*].userName").value(hasItem(DEFAULT_USERNAME.toString())))
                .andExpect(jsonPath("$.[*].password").value(hasItem(DEFAULT_PASSWORD.toString())));
    }

    @Test
    @Transactional
    public void getFolder() throws Exception {
        // Initialize the database
        folderRepository.saveAndFlush(folder);

        // Get the folder
        restFolderMockMvc.perform(get("/api/folders/{id}", folder.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(folder.getId().intValue()))
            .andExpect(jsonPath("$.folderId").value(DEFAULT_FOLDER_ID.toString()))
            .andExpect(jsonPath("$.address").value(DEFAULT_ADDRESS.toString()))
            .andExpect(jsonPath("$.active").value(DEFAULT_ACTIVE.booleanValue()))
            .andExpect(jsonPath("$.weight").value(DEFAULT_WEIGHT))
            .andExpect(jsonPath("$.capacity").value(DEFAULT_CAPACITY.intValue()))
            .andExpect(jsonPath("$.threshold").value(DEFAULT_THRESHOLD))
            .andExpect(jsonPath("$.userName").value(DEFAULT_USERNAME.toString()))
            .andExpect(jsonPath("$.password").value(DEFAULT_PASSWORD.toString()));
    }

    @Test
    @Transactional
    public void getNonExistingFolder() throws Exception {
        // Get the folder
        restFolderMockMvc.perform(get("/api/folders/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateFolder() throws Exception {
        // Initialize the database
        folderRepository.saveAndFlush(folder);

		int databaseSizeBeforeUpdate = folderRepository.findAll().size();

        // Update the folder
        folder.setFolderId(UPDATED_FOLDER_ID);
        folder.setAddress(UPDATED_ADDRESS);
        folder.setActive(UPDATED_ACTIVE);
        folder.setWeight(UPDATED_WEIGHT);
        folder.setCapacity(UPDATED_CAPACITY);
        folder.setThreshold(UPDATED_THRESHOLD);
        folder.setUserName(UPDATED_USERNAME);
        folder.setPassword(UPDATED_PASSWORD);
        restFolderMockMvc.perform(put("/api/folders")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(folder)))
                .andExpect(status().isOk());

        // Validate the Folder in the database
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(databaseSizeBeforeUpdate);
        Folder testFolder = folders.get(folders.size() - 1);
        assertThat(testFolder.getFolderId()).isEqualTo(UPDATED_FOLDER_ID);
        assertThat(testFolder.getAddress()).isEqualTo(UPDATED_ADDRESS);
        assertThat(testFolder.getActive()).isEqualTo(UPDATED_ACTIVE);
        assertThat(testFolder.getWeight()).isEqualTo(UPDATED_WEIGHT);
        assertThat(testFolder.getCapacity()).isEqualTo(UPDATED_CAPACITY);
        assertThat(testFolder.getThreshold()).isEqualTo(UPDATED_THRESHOLD);
        assertThat(testFolder.getUserName()).isEqualTo(UPDATED_USERNAME);
        assertThat(testFolder.getPassword()).isEqualTo(UPDATED_PASSWORD);
    }

    @Test
    @Transactional
    public void deleteFolder() throws Exception {
        // Initialize the database
        folderRepository.saveAndFlush(folder);

		int databaseSizeBeforeDelete = folderRepository.findAll().size();

        // Get the folder
        restFolderMockMvc.perform(delete("/api/folders/{id}", folder.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Folder> folders = folderRepository.findAll();
        assertThat(folders).hasSize(databaseSizeBeforeDelete - 1);
    }
}
