package com.anz.dsc.goodmail.web.rest;

import com.anz.dsc.goodmail.Application;
import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.repository.BatchRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the BatchResource REST controller.
 *
 * @see BatchResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
@IntegrationTest
public class BatchResourceTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");


    private static final DateTime DEFAULT_START_TIME = new DateTime(0L, DateTimeZone.UTC);
    private static final DateTime UPDATED_START_TIME = new DateTime(DateTimeZone.UTC).withMillisOfSecond(0);
    private static final String DEFAULT_START_TIME_STR = dateTimeFormatter.print(DEFAULT_START_TIME);

    private static final DateTime DEFAULT_END_TIME = new DateTime(0L, DateTimeZone.UTC);
    private static final DateTime UPDATED_END_TIME = new DateTime(DateTimeZone.UTC).withMillisOfSecond(0);
    private static final String DEFAULT_END_TIME_STR = dateTimeFormatter.print(DEFAULT_END_TIME);

    private static final Integer DEFAULT_NUMBER_OF_RECEIVED_MAIL = 0;
    private static final Integer UPDATED_NUMBER_OF_RECEIVED_MAIL = 1;

    private static final Integer DEFAULT_NUMBER_OF_PROCESSED_FILE = 0;
    private static final Integer UPDATED_NUMBER_OF_PROCESSED_FILE = 1;

    private static final Integer DEFAULT_NUMBER_OF_REPLIED_MAIL = 0;
    private static final Integer UPDATED_NUMBER_OF_REPLIED_MAIL = 1;

    private static final DateTime DEFAULT_JOB_START_TIME = new DateTime(0L, DateTimeZone.UTC);
    private static final DateTime UPDATED_JOB_START_TIME = new DateTime(DateTimeZone.UTC).withMillisOfSecond(0);
    private static final String DEFAULT_JOB_START_TIME_STR = dateTimeFormatter.print(DEFAULT_JOB_START_TIME);

    private static final DateTime DEFAULT_JOB_END_TIME = new DateTime(0L, DateTimeZone.UTC);
    private static final DateTime UPDATED_JOB_END_TIME = new DateTime(DateTimeZone.UTC).withMillisOfSecond(0);
    private static final String DEFAULT_JOB_END_TIME_STR = dateTimeFormatter.print(DEFAULT_JOB_END_TIME);

    private static final Integer DEFAULT_NUMBER_OF_TRANSFORMED_FILE = 0;
    private static final Integer UPDATED_NUMBER_OF_TRANSFORMED_FILE = 1;

    private static final Long DEFAULT_NUMBER_OF_TRANSFORMED_BYTE = 0L;
    private static final Long UPDATED_NUMBER_OF_TRANSFORMED_BYTE = 1L;

    @Inject
    private BatchRepository batchRepository;

    private MockMvc restBatchMockMvc;

    private Batch batch;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        BatchResource batchResource = new BatchResource();
        ReflectionTestUtils.setField(batchResource, "batchRepository", batchRepository);
        this.restBatchMockMvc = MockMvcBuilders.standaloneSetup(batchResource).build();
    }

    @Before
    public void initTest() {
        batch = new Batch();
        batch.setStartTime(DEFAULT_START_TIME);
        batch.setEndTime(DEFAULT_END_TIME);
        batch.setNumberOfReceivedMail(DEFAULT_NUMBER_OF_RECEIVED_MAIL);
        batch.setNumberOfProcessedFile(DEFAULT_NUMBER_OF_PROCESSED_FILE);
        batch.setNumberOfRepliedMail(DEFAULT_NUMBER_OF_REPLIED_MAIL);
        batch.setJobStartTime(DEFAULT_JOB_START_TIME);
        batch.setJobEndTime(DEFAULT_JOB_END_TIME);
        batch.setNumberOfTransformedFile(DEFAULT_NUMBER_OF_TRANSFORMED_FILE);
        batch.setNumberOfTransformedByte(DEFAULT_NUMBER_OF_TRANSFORMED_BYTE);
    }

    @Test
    @Transactional
    public void createBatch() throws Exception {
        int databaseSizeBeforeCreate = batchRepository.findAll().size();

        // Create the Batch
        restBatchMockMvc.perform(post("/api/batchs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batch)))
                .andExpect(status().isCreated());

        // Validate the Batch in the database
        List<Batch> batchs = batchRepository.findAll();
        assertThat(batchs).hasSize(databaseSizeBeforeCreate + 1);
        Batch testBatch = batchs.get(batchs.size() - 1);
        assertThat(testBatch.getStartTime().toDateTime(DateTimeZone.UTC)).isEqualTo(DEFAULT_START_TIME);
        assertThat(testBatch.getEndTime().toDateTime(DateTimeZone.UTC)).isEqualTo(DEFAULT_END_TIME);
        assertThat(testBatch.getNumberOfReceivedMail()).isEqualTo(DEFAULT_NUMBER_OF_RECEIVED_MAIL);
        assertThat(testBatch.getNumberOfProcessedFile()).isEqualTo(DEFAULT_NUMBER_OF_PROCESSED_FILE);
        assertThat(testBatch.getNumberOfRepliedMail()).isEqualTo(DEFAULT_NUMBER_OF_REPLIED_MAIL);
        assertThat(testBatch.getJobStartTime().toDateTime(DateTimeZone.UTC)).isEqualTo(DEFAULT_JOB_START_TIME);
        assertThat(testBatch.getJobEndTime().toDateTime(DateTimeZone.UTC)).isEqualTo(DEFAULT_JOB_END_TIME);
        assertThat(testBatch.getNumberOfTransformedFile()).isEqualTo(DEFAULT_NUMBER_OF_TRANSFORMED_FILE);
        assertThat(testBatch.getNumberOfTransformedByte()).isEqualTo(DEFAULT_NUMBER_OF_TRANSFORMED_BYTE);
    }

    @Test
    @Transactional
    public void checkStartTimeIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(batchRepository.findAll()).hasSize(0);
        // set the field null
        batch.setStartTime(null);

        // Create the Batch, which fails.
        restBatchMockMvc.perform(post("/api/batchs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batch)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Batch> batchs = batchRepository.findAll();
        assertThat(batchs).hasSize(0);
    }

    @Test
    @Transactional
    public void checkNumberOfReceivedMailIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(batchRepository.findAll()).hasSize(0);
        // set the field null
        batch.setNumberOfReceivedMail(null);

        // Create the Batch, which fails.
        restBatchMockMvc.perform(post("/api/batchs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batch)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Batch> batchs = batchRepository.findAll();
        assertThat(batchs).hasSize(0);
    }

    @Test
    @Transactional
    public void getAllBatchs() throws Exception {
        // Initialize the database
        batchRepository.saveAndFlush(batch);

        // Get all the batchs
        restBatchMockMvc.perform(get("/api/batchs"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(batch.getId().intValue())))
                .andExpect(jsonPath("$.[*].startTime").value(hasItem(DEFAULT_START_TIME_STR)))
                .andExpect(jsonPath("$.[*].endTime").value(hasItem(DEFAULT_END_TIME_STR)))
                .andExpect(jsonPath("$.[*].numberOfReceivedMail").value(hasItem(DEFAULT_NUMBER_OF_RECEIVED_MAIL)))
                .andExpect(jsonPath("$.[*].numberOfProcessedFile").value(hasItem(DEFAULT_NUMBER_OF_PROCESSED_FILE)))
                .andExpect(jsonPath("$.[*].numberOfRepliedMail").value(hasItem(DEFAULT_NUMBER_OF_REPLIED_MAIL)))
                .andExpect(jsonPath("$.[*].jobStartTime").value(hasItem(DEFAULT_JOB_START_TIME_STR)))
                .andExpect(jsonPath("$.[*].jobEndTime").value(hasItem(DEFAULT_JOB_END_TIME_STR)))
                .andExpect(jsonPath("$.[*].numberOfTransformedFile").value(hasItem(DEFAULT_NUMBER_OF_TRANSFORMED_FILE)))
                .andExpect(jsonPath("$.[*].numberOfTransformedByte").value(hasItem(DEFAULT_NUMBER_OF_TRANSFORMED_BYTE.intValue())));
    }

    @Test
    @Transactional
    public void getBatch() throws Exception {
        // Initialize the database
        batchRepository.saveAndFlush(batch);

        // Get the batch
        restBatchMockMvc.perform(get("/api/batchs/{id}", batch.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(batch.getId().intValue()))
            .andExpect(jsonPath("$.startTime").value(DEFAULT_START_TIME_STR))
            .andExpect(jsonPath("$.endTime").value(DEFAULT_END_TIME_STR))
            .andExpect(jsonPath("$.numberOfReceivedMail").value(DEFAULT_NUMBER_OF_RECEIVED_MAIL))
            .andExpect(jsonPath("$.numberOfProcessedFile").value(DEFAULT_NUMBER_OF_PROCESSED_FILE))
            .andExpect(jsonPath("$.numberOfRepliedMail").value(DEFAULT_NUMBER_OF_REPLIED_MAIL))
            .andExpect(jsonPath("$.jobStartTime").value(DEFAULT_JOB_START_TIME_STR))
            .andExpect(jsonPath("$.jobEndTime").value(DEFAULT_JOB_END_TIME_STR))
            .andExpect(jsonPath("$.numberOfTransformedFile").value(DEFAULT_NUMBER_OF_TRANSFORMED_FILE))
            .andExpect(jsonPath("$.numberOfTransformedByte").value(DEFAULT_NUMBER_OF_TRANSFORMED_BYTE.intValue()));
    }

    @Test
    @Transactional
    public void getNonExistingBatch() throws Exception {
        // Get the batch
        restBatchMockMvc.perform(get("/api/batchs/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateBatch() throws Exception {
        // Initialize the database
        batchRepository.saveAndFlush(batch);

		int databaseSizeBeforeUpdate = batchRepository.findAll().size();

        // Update the batch
        batch.setStartTime(UPDATED_START_TIME);
        batch.setEndTime(UPDATED_END_TIME);
        batch.setNumberOfReceivedMail(UPDATED_NUMBER_OF_RECEIVED_MAIL);
        batch.setNumberOfProcessedFile(UPDATED_NUMBER_OF_PROCESSED_FILE);
        batch.setNumberOfRepliedMail(UPDATED_NUMBER_OF_REPLIED_MAIL);
        batch.setJobStartTime(UPDATED_JOB_START_TIME);
        batch.setJobEndTime(UPDATED_JOB_END_TIME);
        batch.setNumberOfTransformedFile(UPDATED_NUMBER_OF_TRANSFORMED_FILE);
        batch.setNumberOfTransformedByte(UPDATED_NUMBER_OF_TRANSFORMED_BYTE);
        restBatchMockMvc.perform(put("/api/batchs")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(batch)))
                .andExpect(status().isOk());

        // Validate the Batch in the database
        List<Batch> batchs = batchRepository.findAll();
        assertThat(batchs).hasSize(databaseSizeBeforeUpdate);
        Batch testBatch = batchs.get(batchs.size() - 1);
        assertThat(testBatch.getStartTime().toDateTime(DateTimeZone.UTC)).isEqualTo(UPDATED_START_TIME);
        assertThat(testBatch.getEndTime().toDateTime(DateTimeZone.UTC)).isEqualTo(UPDATED_END_TIME);
        assertThat(testBatch.getNumberOfReceivedMail()).isEqualTo(UPDATED_NUMBER_OF_RECEIVED_MAIL);
        assertThat(testBatch.getNumberOfProcessedFile()).isEqualTo(UPDATED_NUMBER_OF_PROCESSED_FILE);
        assertThat(testBatch.getNumberOfRepliedMail()).isEqualTo(UPDATED_NUMBER_OF_REPLIED_MAIL);
        assertThat(testBatch.getJobStartTime().toDateTime(DateTimeZone.UTC)).isEqualTo(UPDATED_JOB_START_TIME);
        assertThat(testBatch.getJobEndTime().toDateTime(DateTimeZone.UTC)).isEqualTo(UPDATED_JOB_END_TIME);
        assertThat(testBatch.getNumberOfTransformedFile()).isEqualTo(UPDATED_NUMBER_OF_TRANSFORMED_FILE);
        assertThat(testBatch.getNumberOfTransformedByte()).isEqualTo(UPDATED_NUMBER_OF_TRANSFORMED_BYTE);
    }

    @Test
    @Transactional
    public void deleteBatch() throws Exception {
        // Initialize the database
        batchRepository.saveAndFlush(batch);

		int databaseSizeBeforeDelete = batchRepository.findAll().size();

        // Get the batch
        restBatchMockMvc.perform(delete("/api/batchs/{id}", batch.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Batch> batchs = batchRepository.findAll();
        assertThat(batchs).hasSize(databaseSizeBeforeDelete - 1);
    }
}
