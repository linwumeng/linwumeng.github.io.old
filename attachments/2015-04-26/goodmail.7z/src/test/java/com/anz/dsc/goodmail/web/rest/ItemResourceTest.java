package com.anz.dsc.goodmail.web.rest;

import com.anz.dsc.goodmail.Application;
import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.ItemRepository;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.hamcrest.Matchers.hasItem;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Test class for the ItemResource REST controller.
 *
 * @see ItemResource
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
@IntegrationTest
public class ItemResourceTest {

    private static final DateTimeFormatter dateTimeFormatter = DateTimeFormat.forPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");

    private static final String DEFAULT_ITEM_ID = "SAMPLE_TEXT";
    private static final String UPDATED_ITEM_ID = "UPDATED_TEXT";

    private static final DateTime DEFAULT_RECEIVEDTIME = new DateTime(0L, DateTimeZone.UTC);
    private static final DateTime UPDATED_RECEIVEDTIME = new DateTime(DateTimeZone.UTC).withMillisOfSecond(0);
    private static final String DEFAULT_RECEIVEDTIME_STR = dateTimeFormatter.print(DEFAULT_RECEIVEDTIME);

    private static final Long DEFAULT_SIZE = 0L;
    private static final Long UPDATED_SIZE = 1L;

    private static final Integer DEFAULT_SEQUENCE = 0;
    private static final Integer UPDATED_SEQUENCE = 1;

    private static final Boolean DEFAULT_REPLIED = false;
    private static final Boolean UPDATED_REPLIED = true;
    private static final String DEFAULT_SUBJECT = "SAMPLE_TEXT";
    private static final String UPDATED_SUBJECT = "UPDATED_TEXT";

    private static final Integer DEFAULT_GROUPWEIGHT = 0;
    private static final Integer UPDATED_GROUPWEIGHT = 1;

    @Inject
    private ItemRepository itemRepository;

    private MockMvc restItemMockMvc;

    private Item item;

    @PostConstruct
    public void setup() {
        MockitoAnnotations.initMocks(this);
        ItemResource itemResource = new ItemResource();
        ReflectionTestUtils.setField(itemResource, "itemRepository", itemRepository);
        this.restItemMockMvc = MockMvcBuilders.standaloneSetup(itemResource).build();
    }

    @Before
    public void initTest() {
        item = new Item();
        item.setItemId(DEFAULT_ITEM_ID);
        item.setReceivedTime(DEFAULT_RECEIVEDTIME);
        item.setSize(DEFAULT_SIZE);
        item.setSequence(DEFAULT_SEQUENCE);
        item.setReplied(DEFAULT_REPLIED);
        item.setSubject(DEFAULT_SUBJECT);
        item.setGroupWeight(DEFAULT_GROUPWEIGHT);
    }

    @Test
    @Transactional
    public void createItem() throws Exception {
        int databaseSizeBeforeCreate = itemRepository.findAll().size();

        // Create the Item
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isCreated());

        // Validate the Item in the database
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(databaseSizeBeforeCreate + 1);
        Item testItem = items.get(items.size() - 1);
        assertThat(testItem.getItemId()).isEqualTo(DEFAULT_ITEM_ID);
        assertThat(testItem.getReceivedTime().toDateTime(DateTimeZone.UTC)).isEqualTo(DEFAULT_RECEIVEDTIME);
        assertThat(testItem.getSize()).isEqualTo(DEFAULT_SIZE);
        assertThat(testItem.getSequence()).isEqualTo(DEFAULT_SEQUENCE);
        assertThat(testItem.getReplied()).isEqualTo(DEFAULT_REPLIED);
        assertThat(testItem.getSubject()).isEqualTo(DEFAULT_SUBJECT);
        assertThat(testItem.getGroupWeight()).isEqualTo(DEFAULT_GROUPWEIGHT);
    }

    @Test
    @Transactional
    public void checkItemIdIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(itemRepository.findAll()).hasSize(0);
        // set the field null
        item.setItemId(null);

        // Create the Item, which fails.
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(0);
    }

    @Test
    @Transactional
    public void checkReceivedTimeIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(itemRepository.findAll()).hasSize(0);
        // set the field null
        item.setReceivedTime(null);

        // Create the Item, which fails.
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(0);
    }

    @Test
    @Transactional
    public void checkSizeIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(itemRepository.findAll()).hasSize(0);
        // set the field null
        item.setSize(null);

        // Create the Item, which fails.
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(0);
    }

    @Test
    @Transactional
    public void checkSubjectIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(itemRepository.findAll()).hasSize(0);
        // set the field null
        item.setSubject(null);

        // Create the Item, which fails.
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(0);
    }

    @Test
    @Transactional
    public void checkGroupWeightIsRequired() throws Exception {
        // Validate the database is empty
        assertThat(itemRepository.findAll()).hasSize(0);
        // set the field null
        item.setGroupWeight(null);

        // Create the Item, which fails.
        restItemMockMvc.perform(post("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isBadRequest());

        // Validate the database is still empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(0);
    }

    @Test
    @Transactional
    public void getAllItems() throws Exception {
        // Initialize the database
        itemRepository.saveAndFlush(item);

        // Get all the items
        restItemMockMvc.perform(get("/api/items"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.[*].id").value(hasItem(item.getId().intValue())))
                .andExpect(jsonPath("$.[*].itemId").value(hasItem(DEFAULT_ITEM_ID.toString())))
                .andExpect(jsonPath("$.[*].receivedTime").value(hasItem(DEFAULT_RECEIVEDTIME_STR)))
                .andExpect(jsonPath("$.[*].size").value(hasItem(DEFAULT_SIZE.intValue())))
                .andExpect(jsonPath("$.[*].sequence").value(hasItem(DEFAULT_SEQUENCE)))
                .andExpect(jsonPath("$.[*].replied").value(hasItem(DEFAULT_REPLIED.booleanValue())))
                .andExpect(jsonPath("$.[*].subject").value(hasItem(DEFAULT_SUBJECT.toString())))
                .andExpect(jsonPath("$.[*].groupWeight").value(hasItem(DEFAULT_GROUPWEIGHT)));
    }

    @Test
    @Transactional
    public void getItem() throws Exception {
        // Initialize the database
        itemRepository.saveAndFlush(item);

        // Get the item
        restItemMockMvc.perform(get("/api/items/{id}", item.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON))
            .andExpect(jsonPath("$.id").value(item.getId().intValue()))
            .andExpect(jsonPath("$.itemId").value(DEFAULT_ITEM_ID.toString()))
            .andExpect(jsonPath("$.receivedTime").value(DEFAULT_RECEIVEDTIME_STR))
            .andExpect(jsonPath("$.size").value(DEFAULT_SIZE.intValue()))
            .andExpect(jsonPath("$.sequence").value(DEFAULT_SEQUENCE))
            .andExpect(jsonPath("$.replied").value(DEFAULT_REPLIED.booleanValue()))
            .andExpect(jsonPath("$.subject").value(DEFAULT_SUBJECT.toString()))
            .andExpect(jsonPath("$.groupWeight").value(DEFAULT_GROUPWEIGHT));
    }

    @Test
    @Transactional
    public void getNonExistingItem() throws Exception {
        // Get the item
        restItemMockMvc.perform(get("/api/items/{id}", Long.MAX_VALUE))
                .andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    public void updateItem() throws Exception {
        // Initialize the database
        itemRepository.saveAndFlush(item);

		int databaseSizeBeforeUpdate = itemRepository.findAll().size();

        // Update the item
        item.setItemId(UPDATED_ITEM_ID);
        item.setReceivedTime(UPDATED_RECEIVEDTIME);
        item.setSize(UPDATED_SIZE);
        item.setSequence(UPDATED_SEQUENCE);
        item.setReplied(UPDATED_REPLIED);
        item.setSubject(UPDATED_SUBJECT);
        item.setGroupWeight(UPDATED_GROUPWEIGHT);
        restItemMockMvc.perform(put("/api/items")
                .contentType(TestUtil.APPLICATION_JSON_UTF8)
                .content(TestUtil.convertObjectToJsonBytes(item)))
                .andExpect(status().isOk());

        // Validate the Item in the database
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(databaseSizeBeforeUpdate);
        Item testItem = items.get(items.size() - 1);
        assertThat(testItem.getItemId()).isEqualTo(UPDATED_ITEM_ID);
        assertThat(testItem.getReceivedTime().toDateTime(DateTimeZone.UTC)).isEqualTo(UPDATED_RECEIVEDTIME);
        assertThat(testItem.getSize()).isEqualTo(UPDATED_SIZE);
        assertThat(testItem.getSequence()).isEqualTo(UPDATED_SEQUENCE);
        assertThat(testItem.getReplied()).isEqualTo(UPDATED_REPLIED);
        assertThat(testItem.getSubject()).isEqualTo(UPDATED_SUBJECT);
        assertThat(testItem.getGroupWeight()).isEqualTo(UPDATED_GROUPWEIGHT);
    }

    @Test
    @Transactional
    public void deleteItem() throws Exception {
        // Initialize the database
        itemRepository.saveAndFlush(item);

		int databaseSizeBeforeDelete = itemRepository.findAll().size();

        // Get the item
        restItemMockMvc.perform(delete("/api/items/{id}", item.getId())
                .accept(TestUtil.APPLICATION_JSON_UTF8))
                .andExpect(status().isOk());

        // Validate the database is empty
        List<Item> items = itemRepository.findAll();
        assertThat(items).hasSize(databaseSizeBeforeDelete - 1);
    }
}
