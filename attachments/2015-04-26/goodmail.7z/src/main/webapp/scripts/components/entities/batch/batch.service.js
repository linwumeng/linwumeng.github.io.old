'use strict';

angular.module('goodmailApp')
    .factory('Batch', function ($resource, DateUtils) {
        return $resource('api/batchs/:id', {}, {
            'query': { method: 'GET', isArray: true},
            'get': {
                method: 'GET',
                transformResponse: function (data) {
                    data = angular.fromJson(data);
                    data.startTime = DateUtils.convertDateTimeFromServer(data.startTime);
                    data.endTime = DateUtils.convertDateTimeFromServer(data.endTime);
                    data.jobStartTime = DateUtils.convertDateTimeFromServer(data.jobStartTime);
                    data.jobEndTime = DateUtils.convertDateTimeFromServer(data.jobEndTime);
                    return data;
                }
            },
            'update': { method:'PUT' }
        });
    });
