'use strict';

angular.module('goodmailApp')
    .factory('Register', function ($resource) {
        return $resource('api/register', {}, {
        });
    });


