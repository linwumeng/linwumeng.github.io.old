/* globals $ */
'use strict';

angular.module('goodmailApp')
    .directive('goodmailAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
