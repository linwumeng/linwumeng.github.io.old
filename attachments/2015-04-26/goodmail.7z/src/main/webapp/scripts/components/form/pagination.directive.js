/* globals $ */
'use strict';

angular.module('goodmailApp')
    .directive('goodmailAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });
