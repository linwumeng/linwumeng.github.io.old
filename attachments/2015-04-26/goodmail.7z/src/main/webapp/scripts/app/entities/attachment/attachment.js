'use strict';

angular.module('goodmailApp')
    .config(function ($stateProvider) {
        $stateProvider
            .state('attachment', {
                parent: 'entity',
                url: '/attachment',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Attachments'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/attachment/attachments.html',
                        controller: 'AttachmentController'
                    }
                },
                resolve: {
                }
            })
            .state('attachmentDetail', {
                parent: 'entity',
                url: '/attachment/:id',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Attachment'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/attachment/attachment-detail.html',
                        controller: 'AttachmentDetailController'
                    }
                },
                resolve: {
                }
            });
    });
