'use strict';

angular.module('goodmailApp')
    .controller('ItemController', function ($scope, Item, Folder, Batch, ParseLinks) {
        $scope.items = [];
        $scope.folders = Folder.query();
        $scope.batchs = Batch.query();
        $scope.page = 1;
        $scope.loadAll = function() {
            Item.query({page: $scope.page, per_page: 20}, function(result, headers) {
                $scope.links = ParseLinks.parse(headers('link'));
                for (var i = 0; i < result.length; i++) {
                    $scope.items.push(result[i]);
                }
            });
        };
        $scope.reset = function() {
            $scope.page = 1;
            $scope.items = [];
            $scope.loadAll();
        };
        $scope.loadPage = function(page) {
            $scope.page = page;
            $scope.loadAll();
        };
        $scope.loadAll();

        $scope.showUpdate = function (id) {
            Item.get({id: id}, function(result) {
                $scope.item = result;
                $('#saveItemModal').modal('show');
            });
        };

        $scope.save = function () {
            if ($scope.item.id != null) {
                Item.update($scope.item,
                    function () {
                        $scope.refresh();
                    });
            } else {
                Item.save($scope.item,
                    function () {
                        $scope.refresh();
                    });
            }
        };

        $scope.delete = function (id) {
            Item.get({id: id}, function(result) {
                $scope.item = result;
                $('#deleteItemConfirmation').modal('show');
            });
        };

        $scope.confirmDelete = function (id) {
            Item.delete({id: id},
                function () {
                    $scope.reset();
                    $('#deleteItemConfirmation').modal('hide');
                    $scope.clear();
                });
        };

        $scope.refresh = function () {
            $scope.reset();
            $('#saveItemModal').modal('hide');
            $scope.clear();
        };

        $scope.clear = function () {
            $scope.item = {itemId: null, receivedTime: null, size: null, sequence: null, replied: null, subject: null, groupWeight: null, id: null};
            $scope.editForm.$setPristine();
            $scope.editForm.$setUntouched();
        };
    });
