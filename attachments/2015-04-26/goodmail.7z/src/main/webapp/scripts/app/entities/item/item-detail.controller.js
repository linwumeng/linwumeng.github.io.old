'use strict';

angular.module('goodmailApp')
    .controller('ItemDetailController', function ($scope, $stateParams, Item, Folder, Batch) {
        $scope.item = {};
        $scope.load = function (id) {
            Item.get({id: id}, function(result) {
              $scope.item = result;
            });
        };
        $scope.load($stateParams.id);
    });
