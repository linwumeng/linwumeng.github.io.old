'use strict';

angular.module('goodmailApp')
    .config(function ($stateProvider) {
        $stateProvider
            .state('batch', {
                parent: 'entity',
                url: '/batch',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Batchs'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/batch/batchs.html',
                        controller: 'BatchController'
                    }
                },
                resolve: {
                }
            })
            .state('batchDetail', {
                parent: 'entity',
                url: '/batch/:id',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Batch'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/batch/batch-detail.html',
                        controller: 'BatchDetailController'
                    }
                },
                resolve: {
                }
            });
    });
