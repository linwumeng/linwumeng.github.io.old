'use strict';

angular.module('goodmailApp')
    .controller('AttachmentDetailController', function ($scope, $stateParams, Attachment, Item) {
        $scope.attachment = {};
        $scope.load = function (id) {
            Attachment.get({id: id}, function(result) {
              $scope.attachment = result;
            });
        };
        $scope.load($stateParams.id);
    });
