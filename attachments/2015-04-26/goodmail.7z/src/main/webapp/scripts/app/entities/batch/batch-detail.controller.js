'use strict';

angular.module('goodmailApp')
    .controller('BatchDetailController', function ($scope, $stateParams, Batch, Folder, Item) {
        $scope.batch = {};
        $scope.load = function (id) {
            Batch.get({id: id}, function(result) {
              $scope.batch = result;
            });
        };
        $scope.load($stateParams.id);
    });
