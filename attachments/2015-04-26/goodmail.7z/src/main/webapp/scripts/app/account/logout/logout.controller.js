'use strict';

angular.module('goodmailApp')
    .controller('LogoutController', function (Auth) {
        Auth.logout();
    });
