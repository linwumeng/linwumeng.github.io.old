'use strict';

angular.module('goodmailApp')
    .config(function ($stateProvider) {
        $stateProvider
            .state('folder', {
                parent: 'entity',
                url: '/folder',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Folders'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/folder/folders.html',
                        controller: 'FolderController'
                    }
                },
                resolve: {
                }
            })
            .state('folderDetail', {
                parent: 'entity',
                url: '/folder/:id',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Folder'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/folder/folder-detail.html',
                        controller: 'FolderDetailController'
                    }
                },
                resolve: {
                }
            });
    });
