'use strict';

angular.module('goodmailApp')
    .config(function ($stateProvider) {
        $stateProvider
            .state('item', {
                parent: 'entity',
                url: '/item',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Items'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/item/items.html',
                        controller: 'ItemController'
                    }
                },
                resolve: {
                }
            })
            .state('itemDetail', {
                parent: 'entity',
                url: '/item/:id',
                data: {
                    roles: ['ROLE_USER'],
                    pageTitle: 'Item'
                },
                views: {
                    'content@': {
                        templateUrl: 'scripts/app/entities/item/item-detail.html',
                        controller: 'ItemDetailController'
                    }
                },
                resolve: {
                }
            });
    });
