'use strict';

angular.module('goodmailApp')
    .controller('FolderDetailController', function ($scope, $stateParams, Folder, Batch, Item) {
        $scope.folder = {};
        $scope.load = function (id) {
            Folder.get({id: id}, function(result) {
              $scope.folder = result;
            });
        };
        $scope.load($stateParams.id);
    });
