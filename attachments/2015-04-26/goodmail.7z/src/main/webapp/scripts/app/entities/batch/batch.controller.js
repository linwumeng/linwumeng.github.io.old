'use strict';

angular.module('goodmailApp')
    .controller('BatchController', function ($scope, Batch, Folder, Item, ParseLinks) {
        $scope.batchs = [];
        $scope.folders = Folder.query();
        $scope.items = Item.query();
        $scope.page = 1;
        $scope.loadAll = function() {
            Batch.query({page: $scope.page, per_page: 20}, function(result, headers) {
                $scope.links = ParseLinks.parse(headers('link'));
                for (var i = 0; i < result.length; i++) {
                    $scope.batchs.push(result[i]);
                }
            });
        };
        $scope.reset = function() {
            $scope.page = 1;
            $scope.batchs = [];
            $scope.loadAll();
        };
        $scope.loadPage = function(page) {
            $scope.page = page;
            $scope.loadAll();
        };
        $scope.loadAll();

        $scope.showUpdate = function (id) {
            Batch.get({id: id}, function(result) {
                $scope.batch = result;
                $('#saveBatchModal').modal('show');
            });
        };

        $scope.save = function () {
            if ($scope.batch.id != null) {
                Batch.update($scope.batch,
                    function () {
                        $scope.refresh();
                    });
            } else {
                Batch.save($scope.batch,
                    function () {
                        $scope.refresh();
                    });
            }
        };

        $scope.delete = function (id) {
            Batch.get({id: id}, function(result) {
                $scope.batch = result;
                $('#deleteBatchConfirmation').modal('show');
            });
        };

        $scope.confirmDelete = function (id) {
            Batch.delete({id: id},
                function () {
                    $scope.reset();
                    $('#deleteBatchConfirmation').modal('hide');
                    $scope.clear();
                });
        };

        $scope.refresh = function () {
            $scope.reset();
            $('#saveBatchModal').modal('hide');
            $scope.clear();
        };

        $scope.clear = function () {
            $scope.batch = {startTime: null, endTime: null, numberOfReceivedMail: null, numberOfProcessedFile: null, numberOfRepliedMail: null, jobStartTime: null, jobEndTime: null, numberOfTransformedFile: null, numberOfTransformedByte: null, id: null};
            $scope.editForm.$setPristine();
            $scope.editForm.$setUntouched();
        };
    });
