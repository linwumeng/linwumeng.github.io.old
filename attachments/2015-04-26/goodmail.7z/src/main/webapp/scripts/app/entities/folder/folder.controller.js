'use strict';

angular.module('goodmailApp')
    .controller('FolderController', function ($scope, Folder, Batch, Item, ParseLinks) {
        $scope.folders = [];
        $scope.batchs = Batch.query();
        $scope.items = Item.query();
        $scope.page = 1;
        $scope.loadAll = function() {
            Folder.query({page: $scope.page, per_page: 20}, function(result, headers) {
                $scope.links = ParseLinks.parse(headers('link'));
                for (var i = 0; i < result.length; i++) {
                    $scope.folders.push(result[i]);
                }
            });
        };
        $scope.reset = function() {
            $scope.page = 1;
            $scope.folders = [];
            $scope.loadAll();
        };
        $scope.loadPage = function(page) {
            $scope.page = page;
            $scope.loadAll();
        };
        $scope.loadAll();

        $scope.showUpdate = function (id) {
            Folder.get({id: id}, function(result) {
                $scope.folder = result;
                $('#saveFolderModal').modal('show');
            });
        };

        $scope.save = function () {
            if ($scope.folder.id != null) {
                Folder.update($scope.folder,
                    function () {
                        $scope.refresh();
                    });
            } else {
                Folder.save($scope.folder,
                    function () {
                        $scope.refresh();
                    });
            }
        };

        $scope.delete = function (id) {
            Folder.get({id: id}, function(result) {
                $scope.folder = result;
                $('#deleteFolderConfirmation').modal('show');
            });
        };

        $scope.confirmDelete = function (id) {
            Folder.delete({id: id},
                function () {
                    $scope.reset();
                    $('#deleteFolderConfirmation').modal('hide');
                    $scope.clear();
                });
        };

        $scope.refresh = function () {
            $scope.reset();
            $('#saveFolderModal').modal('hide');
            $scope.clear();
        };

        $scope.clear = function () {
            $scope.folder = {folderId: null, address: null, active: null, weight: null, capacity: null, threshold: null, userName: null, password: null, id: null};
            $scope.editForm.$setPristine();
            $scope.editForm.$setUntouched();
        };
    });
