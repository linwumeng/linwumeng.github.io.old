'use strict';

angular.module('goodmailApp')
    .controller('AttachmentController', function ($scope, Attachment, Item, ParseLinks) {
        $scope.attachments = [];
        $scope.items = Item.query();
        $scope.page = 1;
        $scope.loadAll = function() {
            Attachment.query({page: $scope.page, per_page: 20}, function(result, headers) {
                $scope.links = ParseLinks.parse(headers('link'));
                for (var i = 0; i < result.length; i++) {
                    $scope.attachments.push(result[i]);
                }
            });
        };
        $scope.reset = function() {
            $scope.page = 1;
            $scope.attachments = [];
            $scope.loadAll();
        };
        $scope.loadPage = function(page) {
            $scope.page = page;
            $scope.loadAll();
        };
        $scope.loadAll();

        $scope.showUpdate = function (id) {
            Attachment.get({id: id}, function(result) {
                $scope.attachment = result;
                $('#saveAttachmentModal').modal('show');
            });
        };

        $scope.save = function () {
            if ($scope.attachment.id != null) {
                Attachment.update($scope.attachment,
                    function () {
                        $scope.refresh();
                    });
            } else {
                Attachment.save($scope.attachment,
                    function () {
                        $scope.refresh();
                    });
            }
        };

        $scope.delete = function (id) {
            Attachment.get({id: id}, function(result) {
                $scope.attachment = result;
                $('#deleteAttachmentConfirmation').modal('show');
            });
        };

        $scope.confirmDelete = function (id) {
            Attachment.delete({id: id},
                function () {
                    $scope.reset();
                    $('#deleteAttachmentConfirmation').modal('hide');
                    $scope.clear();
                });
        };

        $scope.refresh = function () {
            $scope.reset();
            $('#saveAttachmentModal').modal('hide');
            $scope.clear();
        };

        $scope.clear = function () {
            $scope.attachment = {name: null, path: null, size: null, type: null, id: null};
            $scope.editForm.$setPristine();
            $scope.editForm.$setUntouched();
        };
    });
