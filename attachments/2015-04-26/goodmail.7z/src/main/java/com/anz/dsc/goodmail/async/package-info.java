/**
 * Async helpers.
 */
package com.anz.dsc.goodmail.async;
