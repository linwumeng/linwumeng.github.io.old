package com.anz.dsc.goodmail.repository;

import com.anz.dsc.goodmail.domain.Item;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


/**
 * Spring Data JPA repository for the Item entity.
 */
public interface ItemRepository extends JpaRepository<Item,Long> {

    @Query("select i from Item i where i.replied=:replied and i.sequence is null order by i.receivedTime asc")
    List<Item> findAllByReplied(@Param("replied")Boolean replied, Sort sort);

    @Query("select i from Item i where i.replied=:replied and i.sequence>0 order by i.sequence asc")
    Page<Item> findAllScheduled(@Param("replied")Boolean replied, Pageable page);
}
