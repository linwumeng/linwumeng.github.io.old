package com.anz.dsc.goodmail.web.rest;

import com.anz.dsc.goodmail.repository.BatchRepository;
import com.anz.dsc.goodmail.repository.ItemRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.inject.Inject;

/**
 * Created by linwum on 2015/7/9.
 */
@RestController
@RequestMapping("/api")
public class TaskExecutorResource {

    private Logger log = LoggerFactory.getLogger(TaskExecutorResource.class);

    static volatile boolean active = true;

    @Inject
    private ItemRepository itemRepository;

    @Inject
    private BatchRepository batchRepository;

    public boolean isActive() {
        return active;
    }

    @RequestMapping(value = "/pollTask/stop",
        method = RequestMethod.GET)
    public boolean stopTask() {
        itemRepository.flush();
        batchRepository.flush();

        active = false;
        log.info("Scheduler shutdown.");

        return active;
    }

    @RequestMapping(value = "/pollTask/start",
        method = RequestMethod.GET)
    public boolean startTask() {
        active = true;
        log.info("Scheduler restart.");

        return active;
    }
}
