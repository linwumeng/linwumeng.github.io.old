package com.anz.dsc.goodmail.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Folder.
 */
@Entity
@Table(name = "FOLDER")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Folder implements Serializable, Comparable<Folder> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "folder_id", nullable = false)
    private String folderId;

    @NotNull
    @Column(name = "address", nullable = false)
    private String address;

    @Column(name = "active")
    private Boolean active;

    @NotNull
    @Column(name = "weight", nullable = false)
    private Integer weight;

    @NotNull
    @Column(name = "capacity", nullable = false)
    private Long capacity;

    @NotNull
    @Min(value = 50)
    @Max(value = 95)
    @Column(name = "threshold", nullable = false)
    private Integer threshold;

    @NotNull
    @Column(name = "userName", nullable = false)
    private String userName;

    @NotNull
    @Column(name = "password", nullable = false)
    private String password;

    @ManyToMany(mappedBy = "folders")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Batch> batchs = new HashSet<>();

    @OneToMany(mappedBy = "folder")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Item> items = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Long getCapacity() {
        return capacity;
    }

    public void setCapacity(Long capacity) {
        this.capacity = capacity;
    }

    public Integer getThreshold() {
        return threshold;
    }

    public void setThreshold(Integer threshold) {
        this.threshold = threshold;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Set<Batch> getBatchs() {
        return batchs;
    }

    public void setBatchs(Set<Batch> batchs) {
        this.batchs = batchs;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "Folder{" +
                "id=" + id +
                ", folderId='" + folderId + "'" +
                ", address='" + address + "'" +
                ", active='" + active + "'" +
                ", weight='" + weight + "'" +
                ", capacity='" + capacity + "'" +
                ", threshold='" + threshold + "'" +
                ", userName='" + userName + "'" +
                ", password='" + password + "'" +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Folder)) return false;

        Folder folder = (Folder) o;

        return address.equals(folder.address);

    }

    @Override
    public int hashCode() {
        return address.hashCode();
    }

    @Override
    public int compareTo(Folder o) {
        Integer w1 = this.weight == null ? 0 : this.weight;
        Integer w2 = o.weight == null ? 0 : o.weight;

        if (w1.equals(w2)) {
            Long c1 = this.capacity == null ? 0L : this.capacity;
            Long c2 = o.capacity == null ? 0L : o.capacity;
            return c1.compareTo(c2);
        }

        return w1.compareTo(w2);
    }
}
