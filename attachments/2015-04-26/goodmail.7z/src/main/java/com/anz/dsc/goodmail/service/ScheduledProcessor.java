package com.anz.dsc.goodmail.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class ScheduledProcessor {

	@Autowired
	private InboxService inboxService;

	@Scheduled(fixedDelay = 5000)
	public void process() {
        inboxService.poll();
	}

}
