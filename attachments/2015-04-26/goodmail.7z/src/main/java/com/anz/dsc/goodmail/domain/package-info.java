/**
 * JPA domain objects.
 */
package com.anz.dsc.goodmail.domain;
