package com.anz.dsc.goodmail.service.impl;

import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.domain.Folder;
import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.BatchRepository;
import com.anz.dsc.goodmail.repository.FolderRepository;
import com.anz.dsc.goodmail.service.BasicFilter;
import com.anz.dsc.goodmail.service.MailScheduleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.Environment;
import reactor.bus.Event;
import reactor.bus.EventBus;
import reactor.fn.BiFunction;
import reactor.fn.Consumer;
import reactor.fn.Predicate;
import reactor.rx.Streams;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.inject.Inject;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

@Service
public class BasicFilterImpl implements BasicFilter {

    private final Logger log = LoggerFactory.getLogger(BasicFilterImpl.class);

//    @Inject
//    private ItemRepository itemRepository;

    @Resource(name = "scheduler")
    private EventBus scheduler;

    @Inject
    private FolderRepository folderRepository;

    @Inject
    private BatchRepository batchRepository;

    @Inject
    private MailScheduleService mailScheduleService;

    @PostConstruct
    public void initEnv() {
        Environment.initializeIfEmpty().assignErrorJournal();
    }

    @Override
    public void filterAndAssemble(final Batch batch, Set<Item> data, final Long folderId) {
        final ConcurrentSkipListSet<Item> filtered = new ConcurrentSkipListSet<>();

        Streams.from(data).dispatchOn(Environment.cachedDispatcher())
            .filter(new Predicate<Item>() {
                @Override
                public boolean test(Item item) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    return true;
                }
            })
            .reduce(filtered, new BiFunction<Set<Item>, Item, Set<Item>>() {
                @Override
                @Transactional
                public Set<Item> apply(Set<Item> items, Item item) {
                    Folder f = folderRepository.findOne(folderId);
                    item.setFolder(f);
                    item.setGroupWeight(f.getWeight());
                    filtered.add(item);
                    return filtered;
                }
            })
            .consume(new Consumer<Set<Item>>() {
                @Transactional
                public void accept(Set<Item> items) {
//                filtered.addAll(items);
                    log.info("All {}", items);

                    batch.addFolder(folderRepository.findOne(folderId));
                    batch.setItems(items);

                    batchRepository.saveAndFlush(batch);

                    log.info("Create batch for mails {}", batch);

                    scheduler.notify("schedule.mail", Event.wrap(batch));
//                    try {
//                        mailScheduleService.schedule(batch);
//                    } catch (InvalidDataAccessApiUsageException | IllegalArgumentException e){
//                        //Ignore this exception
//                    }
                }
            });
    }
}
