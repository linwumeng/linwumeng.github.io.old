/**
 * Locale specific code.
 */
package com.anz.dsc.goodmail.config.locale;
