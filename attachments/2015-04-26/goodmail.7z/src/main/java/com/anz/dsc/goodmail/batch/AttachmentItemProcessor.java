package com.anz.dsc.goodmail.batch;

import com.anz.dsc.goodmail.domain.Item;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

/**
 * Created by linwum on 2015/7/6.
 */
public class AttachmentItemProcessor implements ItemProcessor<Item, Item> {
    private static final Logger log = LoggerFactory.getLogger(AttachmentItemProcessor.class);

    @Override
    public Item process(final Item item) throws Exception {

        log.info("Converting (" + item + ")");
        item.setReplied(true);
        try {
            Thread.sleep(150);
        }catch (InterruptedException e){
            
        }
        return item;
    }
}
