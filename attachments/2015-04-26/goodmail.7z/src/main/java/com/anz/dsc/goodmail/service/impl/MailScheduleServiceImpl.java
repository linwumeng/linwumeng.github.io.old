package com.anz.dsc.goodmail.service.impl;

import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.service.MailScheduleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.bus.Event;

@Service
@Transactional
public class MailScheduleServiceImpl implements MailScheduleService {

    private final Logger log = LoggerFactory.getLogger(MailScheduleServiceImpl.class);

//    @Inject
//    private BatchRepository batchRepository;

    @Override
    public void schedule(Batch batch) {
        log.info("Schedule for {}", batch);
    }
}
