package com.anz.dsc.goodmail.service.impl;

import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.ItemRepository;
import com.anz.dsc.goodmail.service.MailScheduleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.bus.Event;

import javax.inject.Inject;
import java.util.*;

@Service
public class MailScheduleServiceImpl implements MailScheduleService {

    private final Logger log = LoggerFactory.getLogger(MailScheduleServiceImpl.class);

    @Inject
    private ItemRepository itemRepository;

    @Inject
    private JobLauncher jobLauncher;

    @Inject
    private Job job;

    @Override
    @Transactional
    public void schedule(Batch batch) {
        log.info("Schedule for {}", batch);

        List<Item> queue = itemRepository.findAllByReplied(false, new Sort(
            new Sort.Order(Sort.Direction.ASC, "groupWeight"),
            new Sort.Order(Sort.Direction.ASC, "receivedTime")
        ));

        List<Item> requests = new ArrayList<>(queue);
        Collections.sort(requests, new Comparator<Item>() {
            @Override
            public int compare(Item o1, Item o2) {
                //reorder by size only!
                //must consider more dimensions.
                return o1.getSize().compareTo(o2.getSize());
            }
        });
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        int i = 1;
        for (Iterator<Item> iter = requests.iterator(); iter.hasNext(); ) {
            Item it = iter.next();
            it.setSequence(i++);
            log.info("Set sequence {}", it);
        }

        itemRepository.save(requests);

        try {
            jobLauncher.run(job, new JobParametersBuilder().addDate("startTime", new Date()).toJobParameters());
        } catch (Exception e) {
            log.warn(e.getMessage(), e);
        }
    }

    @Override
    public void accept(Event<Batch> event) {
        schedule(event.getData());
    }
}
