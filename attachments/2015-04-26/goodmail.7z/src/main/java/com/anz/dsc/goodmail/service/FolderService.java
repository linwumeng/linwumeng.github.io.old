package com.anz.dsc.goodmail.service;

import com.anz.dsc.goodmail.domain.Folder;
import com.anz.dsc.goodmail.web.rest.dto.FolderDTO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

/**
 * Created by linwum on 2015/6/27.
 */
@Service
public class FolderService {
    public Folder createFolder(FolderDTO folderDTO) {
        Folder folder = new Folder();

        BeanUtils.copyProperties(folderDTO, folder);

        folder.setId(folderDTO.getId());
        folder.setFolderId(folderDTO.getAddress());
        folder.setCapacity(folderDTO.getCapacity() * 1024 * 1024);

        return folder;
    }
}
