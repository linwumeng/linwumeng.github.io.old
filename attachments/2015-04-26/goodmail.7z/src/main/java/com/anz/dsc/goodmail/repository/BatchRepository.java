package com.anz.dsc.goodmail.repository;

import com.anz.dsc.goodmail.domain.Batch;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * Spring Data JPA repository for the Batch entity.
 */
public interface BatchRepository extends JpaRepository<Batch,Long> {

    @Query("select batch from Batch batch left join fetch batch.folders left join fetch batch.items where batch.id =:id")
    Batch findOneWithEagerRelationships(@Param("id") Long id);

}
