package com.anz.dsc.goodmail.service.impl;

import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.domain.Folder;
import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.FolderRepository;
import com.anz.dsc.goodmail.service.BasicFilter;
import com.anz.dsc.goodmail.service.InboxService;
import com.anz.dsc.goodmail.service.MailScheduleService;
import com.anz.dsc.goodmail.web.rest.TaskExecutorResource;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.inject.Inject;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class InboxServiceImpl implements InboxService {

    private final Logger log = LoggerFactory.getLogger(InboxServiceImpl.class);

    @Inject
    private FolderRepository folderRepository;

    @Inject
    private BasicFilter basicFilter;

    @Inject
    private TaskExecutorResource taskExecutorResource;

//    @Inject
//    private MailScheduleService mailScheduleService;
//
//    @Inject
//    private JobLauncher jobLauncher;
//
//    @Inject
//    private JobExplorer jobExplorer;
//
//    @Inject
//    private Job job;
    private volatile boolean running = false;

    @Override
    @Scheduled(fixedDelay = 5000)
    @Async
    public void poll() {
        if (!taskExecutorResource.isActive())
            return;

        log.info("start polling inbox...");
        //Get inbox list by repository
        //Poll the active inboxes to get mail list
        List<Folder> folders = folderRepository.findAllByActive(true);

        Batch batch = new Batch();
        batch.setNumberOfReceivedMail(0);

        int[] mailNumbers = new int[folders.size()];
        for (int i = 0; i < mailNumbers.length; i++) {
            mailNumbers[i] = (int) (Math.random() * 100) + 1;
            batch.setNumberOfReceivedMail(batch.getNumberOfRepliedMail() + mailNumbers[i]);
        }

        batch.setStartTime(new DateTime());

        //send message to the filter
        for (int i = 0; i < folders.size(); i++) {
            Folder f = folders.get(i);
//            batch.addFolder(f);
            Set<Item> inbox = new HashSet<>();
            log.info("process for {}", f);

            handleItems(i * folders.size(), batch, mailNumbers[i], f, inbox);

        }


//        try {
//            mailScheduleService.schedule(batch);
//            if (!running) {
//                log.info("start job.");
//                jobLauncher.run(job, new JobParametersBuilder().addDate("startTime", new Date()).toJobParameters());
//                running = true;
//            }
//        } catch (InvalidDataAccessApiUsageException | IllegalArgumentException e){
            //Ignore this exception
//        }

    }

    @Override
    public void next() {
        running = false;
    }

    @Transactional
    private void handleItems(int i, Batch batch, int mailNumber, Folder f, Set<Item> inbox) {
        int total = mailNumber;
        for (int j = 0; j < total; j++) {
            Item item = new Item();
//                item.setFolder(f);
            item.setItemId(j + "" + new Date());
            item.setSubject("no subject." + i + j);
            item.setReplied(false);
            item.setSize(1024 * ((int) (Math.random() * 1000) + 25L));
            item.setReceivedTime(new DateTime());

            inbox.add(item);
//                log.info("Get a mail: " + item);
        }

        log.info("receive {} mails, {}", inbox.size(), inbox);

        //Step 2 to filter mails by sender and attachment
        basicFilter.filterAndAssemble(batch, inbox, f.getId());
    }

}
