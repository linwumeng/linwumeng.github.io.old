/**
 * Spring MVC REST controllers.
 */
package com.anz.dsc.goodmail.web.rest;
