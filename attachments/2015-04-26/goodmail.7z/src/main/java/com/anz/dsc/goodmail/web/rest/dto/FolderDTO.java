package com.anz.dsc.goodmail.web.rest.dto;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * Created by linwum on 2015/6/27.
 */
public class FolderDTO {

    private Long id;

    @NotNull
    private String address;

    @NotNull
    private Boolean active;

    @NotNull
    @Min(value = 1)
    private Integer weight;

    @NotNull
    private Long capacity;

    @NotNull
    @Min(value = 50)
    @Max(value = 95)
    private Integer threshold;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getThreshold() {
        return threshold;
    }

    public void setThreshold(Integer threshold) {
        this.threshold = threshold;
    }

    public Long getCapacity() {
        return capacity;
    }

    public void setCapacity(Long capacity) {
        // transform to byte
        this.capacity = capacity;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "FolderDTO{" +
            "id='" + id + '\'' +
            ", address='" + address + '\'' +
            ", active=" + active +
            ", weight=" + weight +
            ", capacity=" + capacity +
            ", threshold=" + threshold +
            '}';
    }
}
