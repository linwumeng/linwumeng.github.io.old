/**
 * Service layer beans.
 */
package com.anz.dsc.goodmail.service;
