package com.anz.dsc.goodmail.service;

import com.anz.dsc.goodmail.domain.Batch;
import com.anz.dsc.goodmail.domain.Item;
import reactor.bus.Event;
import reactor.fn.Consumer;

import java.util.List;
import java.util.Map;
import java.util.Set;

public interface BasicFilter {

    void filterAndAssemble(Batch batch, Set<Item> data, Long folderId);
}
