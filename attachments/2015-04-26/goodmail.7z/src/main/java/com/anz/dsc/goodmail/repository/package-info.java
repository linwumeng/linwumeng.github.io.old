/**
 * Spring Data JPA repositories.
 */
package com.anz.dsc.goodmail.repository;
