package com.anz.dsc.goodmail.config;

import com.anz.dsc.goodmail.batch.AttachmentItemProcessor;
import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.ItemRepository;
import com.codahale.metrics.MetricRegistry;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.batch.BasicBatchConfigurer;
import org.springframework.boot.autoconfigure.batch.BatchDatabaseInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.data.domain.Sort;
import org.springframework.jdbc.datasource.init.DatabasePopulatorUtils;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by linwum on 2015/7/6.
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    private Logger log = LoggerFactory.getLogger(BatchConfiguration.class);

    @Inject
    private ItemRepository itemRepository;

    @Inject
    private ResourceLoader resourceLoader;

    @Autowired(required = false)
    private MetricRegistry metricRegistry;

    private DataSource dataSource;

//    @PostConstruct
    public void initialize() {

        log.debug("Configuring H2 Datasource");
        HikariConfig config = new HikariConfig();
        config.setDataSourceClassName("org.h2.jdbcx.JdbcDataSource");
        config.addDataSourceProperty("url", "jdbc:h2:mem:springbatch;DB_CLOSE_DELAY=-1");
        config.addDataSourceProperty("user", "");
        config.addDataSourceProperty("password", "");

        if (metricRegistry != null) {
            config.setMetricRegistry(metricRegistry);
        }
        dataSource = new HikariDataSource(config);
    }

    public class H2BatchDatabaseInitializer extends BatchDatabaseInitializer {

        public H2BatchDatabaseInitializer(ResourceLoader resourceLoader, DataSource dataSource) {
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
            String schemaLocation = "classpath:org/springframework/batch/core/schema-h2.sql";
            populator.addScript(resourceLoader.getResource(schemaLocation));
            populator.setContinueOnError(true);
            DatabasePopulatorUtils.execute(populator, dataSource);

            log.debug("Configuring H2BatchDatabaseInitializer");
        }

    }

//    @Bean
    public BatchDatabaseInitializer batchDatabaseInitializer() {
        return new H2BatchDatabaseInitializer(resourceLoader, dataSource);
    }

//    @Bean
    public JobExplorer jobExplorer() throws Exception {
        log.debug("Configuring jobExplorer");

        JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
        factory.setDataSource(dataSource);
        factory.afterPropertiesSet();
        return factory.getObject();
    }

//    @Bean
    public BatchConfigurer basicBatchConfigurer() {
        log.debug("Configuring Batch ...");

        return new BasicBatchConfigurer(dataSource);
    }

    // tag::readerwriterprocessor[]
    @Bean
    public ItemReader<Item> reader() throws Exception {
        RepositoryItemReader<Item> reader = new RepositoryItemReader<Item>();
        reader.setRepository(itemRepository);
        Map<String, Sort.Direction> sorts = new HashMap<>();
        List<Object> args = new ArrayList<>(1);
        args.add(Boolean.FALSE);
//        args.add(0);
        sorts.put("sequence", Sort.Direction.ASC);
        reader.setSort(sorts);
        reader.setMethodName("findAllScheduled");
        reader.setArguments(args);
        reader.afterPropertiesSet();
        return reader;
    }

    @Bean
    public ItemProcessor<Item, Item> processor() {
        return new AttachmentItemProcessor();
    }

    @Bean
    public ItemWriter<Item> writer() {
        RepositoryItemWriter<Item> writer = new RepositoryItemWriter<Item>();
        writer.setRepository(itemRepository);
        writer.setMethodName("save");
        return writer;
    }
    // end::readerwriterprocessor[]

    // tag::jobstep[]
    @Bean
    public Job transformAttachment(JobBuilderFactory jobs, Step s1, JobExecutionListener listener) {
        return jobs.get("transformAttachment")
            .incrementer(new RunIdIncrementer())
            .listener(listener)
            .flow(s1)
            .end()
            .build();
    }

    @Bean
    public Step step1(StepBuilderFactory stepBuilderFactory, ItemReader<Item> reader,
                      ItemWriter<Item> writer, ItemProcessor<Item, Item> processor) {
        return stepBuilderFactory.get("step1")
            .<Item, Item>chunk(10)
            .reader(reader)
            .processor(processor)
            .writer(writer)
            .build();
    }
    // end::jobstep[]

}
