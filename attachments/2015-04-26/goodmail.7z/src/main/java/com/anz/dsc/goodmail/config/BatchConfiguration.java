package com.anz.dsc.goodmail.config;

import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.repository.ItemRepository;
import com.anz.dsc.goodmail.batch.AttachmentItemProcessor;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.data.RepositoryItemReader;
import org.springframework.batch.item.data.RepositoryItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.Sort;

import javax.inject.Inject;
import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by linwum on 2015/7/6.
 */
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

    @Inject
    private ItemRepository itemRepository;

    // tag::readerwriterprocessor[]
    @Bean
    public ItemReader<Item> reader() throws Exception {
        RepositoryItemReader<Item> reader = new RepositoryItemReader<Item>();
        reader.setRepository(itemRepository);
        Map<String, Sort.Direction> sorts = new HashMap<>();
        List<Object> args = new ArrayList<>(1);
        args.add(Boolean.FALSE);
//        args.add(0);
        sorts.put("sequence", Sort.Direction.ASC);
        reader.setSort(sorts);
        reader.setMethodName("findAllScheduled");
        reader.setArguments(args);
        reader.afterPropertiesSet();
        return reader;
    }

    @Bean
    public ItemProcessor<Item, Item> processor() {
        return new AttachmentItemProcessor();
    }

    @Bean
    public ItemWriter<Item> writer() {
        RepositoryItemWriter<Item> writer = new RepositoryItemWriter<Item>();
        writer.setRepository(itemRepository);
        writer.setMethodName("save");
        return writer;
    }
    // end::readerwriterprocessor[]

    // tag::jobstep[]
    @Bean
    public Job transformAttachment(JobBuilderFactory jobs, Step s1, JobExecutionListener listener) {
        return jobs.get("transformAttachment")
            .incrementer(new RunIdIncrementer())
            .listener(listener)
            .flow(s1)
            .end()
            .build();
    }

    @Bean
    public Step step1(StepBuilderFactory stepBuilderFactory, ItemReader<Item> reader,
                      ItemWriter<Item> writer, ItemProcessor<Item, Item> processor) {
        return stepBuilderFactory.get("step1")
            .<Item, Item> chunk(10)
            .reader(reader)
            .processor(processor)
            .writer(writer)
            .build();
    }
    // end::jobstep[]

}
