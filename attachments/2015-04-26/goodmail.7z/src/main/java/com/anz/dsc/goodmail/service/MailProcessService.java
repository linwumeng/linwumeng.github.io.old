package com.anz.dsc.goodmail.service;

import com.anz.dsc.goodmail.domain.Item;
import reactor.bus.Event;
import reactor.fn.Consumer;

public interface MailProcessService extends Consumer<Event<Item>> {

}
