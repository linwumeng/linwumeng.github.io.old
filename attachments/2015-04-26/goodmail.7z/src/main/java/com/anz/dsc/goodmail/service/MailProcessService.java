package com.anz.dsc.goodmail.service;

public interface MailProcessService {

}
