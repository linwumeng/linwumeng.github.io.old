package com.anz.dsc.goodmail.repository;

import com.anz.dsc.goodmail.domain.Attachment;
import org.springframework.data.jpa.repository.*;

import java.util.List;

/**
 * Spring Data JPA repository for the Attachment entity.
 */
public interface AttachmentRepository extends JpaRepository<Attachment,Long> {

}
