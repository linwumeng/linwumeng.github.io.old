/**
 * Spring Framework configuration files.
 */
package com.anz.dsc.goodmail.config;
