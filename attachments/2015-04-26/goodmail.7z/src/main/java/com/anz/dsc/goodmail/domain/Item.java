package com.anz.dsc.goodmail.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.anz.dsc.goodmail.domain.util.CustomDateTimeDeserializer;
import com.anz.dsc.goodmail.domain.util.CustomDateTimeSerializer;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;
import java.util.concurrent.ConcurrentSkipListSet;

/**
 * A Item.
 */
@Entity
@Table(name = "ITEM")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Item implements Serializable, Comparable<Item> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "item_id", nullable = false)
    private String itemId;

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "timestamp", nullable = false)
    private DateTime timestamp;

    @NotNull
    @Column(name = "size", nullable = false)
    private Long size;

    @Column(name = "sequence")
    private Integer sequence;

    @Column(name = "replied")
    private Boolean replied;

    @NotNull
    @Column(name = "subject", nullable = false)
    private String subject;

    @ManyToOne
    private Folder folder;

    @ManyToMany(mappedBy = "items")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Batch> batchs = new ConcurrentSkipListSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public DateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(DateTime timestamp) {
        this.timestamp = timestamp;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Boolean getReplied() {
        return replied;
    }

    public void setReplied(Boolean replied) {
        this.replied = replied;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Folder getFolder() {
        return folder;
    }

    public void setFolder(Folder folder) {
        this.folder = folder;
    }

    public Set<Batch> getBatchs() {
        return batchs;
    }

    public void setBatchs(Set<Batch> batchs) {
        this.batchs = batchs;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Item)) return false;

        Item item = (Item) o;

        if (itemId != null ? !itemId.equals(item.itemId) : item.itemId != null) return false;
        if (timestamp != null ? !timestamp.equals(item.timestamp) : item.timestamp != null) return false;
        if (size != null ? !size.equals(item.size) : item.size != null) return false;
        if (subject != null ? !subject.equals(item.subject) : item.subject != null) return false;
        return !(folder != null ? !folder.equals(item.folder) : item.folder != null);

    }

    @Override
    public int hashCode() {
        int result = itemId != null ? itemId.hashCode() : 0;
        result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
        result = 31 * result + (size != null ? size.hashCode() : 0);
        result = 31 * result + (subject != null ? subject.hashCode() : 0);
        result = 31 * result + (folder != null ? folder.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", itemId='" + itemId + "'" +
                ", timestamp='" + timestamp + "'" +
                ", size='" + size + "'" +
                ", sequence='" + sequence + "'" +
                ", replied='" + replied + "'" +
                ", subject='" + subject + "'" +
                '}';
    }

    public void addBatch(Batch batch) {
        batchs.add(batch);
    }

    @Override
    public int compareTo(Item o) {
        if (null == o) {
            return 1;
        }
        DateTime t1 = this.timestamp == null ? new DateTime(0) : this.timestamp;
        DateTime t2 = o.timestamp == null ? new DateTime(0) : o.timestamp;
        if (!t1.equals(t2)) {
            return t1.compareTo(t2);
        }

        Integer s1 = this.sequence == null ? 0 : this.sequence;
        Integer s2 = o.sequence == null ? 0 : o.sequence;
        if (!s1.equals(s2)) {
            return s1.compareTo(s2);
        }

        return this.subject.compareTo(o.subject);
    }
}
