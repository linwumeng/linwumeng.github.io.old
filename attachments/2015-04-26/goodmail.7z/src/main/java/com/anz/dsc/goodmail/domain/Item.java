package com.anz.dsc.goodmail.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.anz.dsc.goodmail.domain.util.CustomDateTimeDeserializer;
import com.anz.dsc.goodmail.domain.util.CustomDateTimeSerializer;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;
import javax.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.Objects;

/**
 * A Item.
 */
@Entity
@Table(name = "ITEM")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Item implements Serializable, Comparable<Item> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Column(name = "item_id", nullable = false)
    private String itemId;

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "receivedTime", nullable = false)
    private DateTime receivedTime;

    @NotNull
    @Column(name = "size", nullable = false)
    private Long size;

    @Column(name = "sequence")
    private Integer sequence;

    @Column(name = "replied")
    private Boolean replied;

    @NotNull
    @Column(name = "subject", nullable = false)
    private String subject;

    @NotNull
    @Column(name = "groupWeight", nullable = false)
    private Integer groupWeight;

    @ManyToOne
    private Folder folder;

    @ManyToMany(mappedBy = "items")
    @JsonIgnore
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    private Set<Batch> batchs = new HashSet<>();

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }

    public DateTime getReceivedTime() {
        return receivedTime;
    }

    public void setReceivedTime(DateTime receivedTime) {
        this.receivedTime = receivedTime;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Boolean getReplied() {
        return replied;
    }

    public void setReplied(Boolean replied) {
        this.replied = replied;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Integer getGroupWeight() {
        return groupWeight;
    }

    public void setGroupWeight(Integer groupWeight) {
        this.groupWeight = groupWeight;
    }

    public Folder getFolder() {
        return folder;
    }

    public void setFolder(Folder folder) {
        this.folder = folder;
    }

    public Set<Batch> getBatchs() {
        return batchs;
    }

    public void setBatchs(Set<Batch> batchs) {
        this.batchs = batchs;
    }

    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", itemId='" + itemId + "'" +
                ", receivedTime='" + receivedTime + "'" +
                ", size='" + size + "'" +
                ", sequence='" + sequence + "'" +
                ", replied='" + replied + "'" +
                ", subject='" + subject + "'" +
                ", groupWeight='" + groupWeight + "'" +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Item)) return false;

        Item item = (Item) o;

        if (!itemId.equals(item.itemId)) return false;
        if (!receivedTime.equals(item.receivedTime)) return false;
        if (!size.equals(item.size)) return false;
        if (!subject.equals(item.subject)) return false;
        return !(folder != null ? !folder.equals(item.folder) : item.folder != null);

    }

    @Override
    public int hashCode() {
        int result = itemId.hashCode();
        result = 31 * result + receivedTime.hashCode();
        result = 31 * result + size.hashCode();
        result = 31 * result + subject.hashCode();
        result = 31 * result + (folder != null ? folder.hashCode() : 0);
        return result;
    }

    @Override
    public int compareTo(Item o) {
        return receivedTime.compareTo(o.receivedTime);
    }
}
