/**
 * Swagger api specific code.
 */
package com.anz.dsc.goodmail.config.apidoc;