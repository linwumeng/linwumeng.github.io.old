package com.anz.dsc.goodmail.service.impl;

import com.anz.dsc.goodmail.domain.Item;
import com.anz.dsc.goodmail.service.MailProcessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.bus.Event;

@Service
@Transactional
public class MailProcessServiceImpl implements MailProcessService {

    private final Logger log = LoggerFactory.getLogger(MailProcessServiceImpl.class);

    public void accept(Event<Item> itemEvent) {

    }
}
