package com.anz.dsc.goodmail.service;

import com.anz.dsc.goodmail.domain.Batch;
import reactor.bus.Event;
import reactor.fn.Consumer;

public interface MailScheduleService extends Consumer<Event<Batch>> {

    void schedule(Batch batch);

    @Override
    void accept(Event<Batch> event);
}
