package com.anz.dsc.goodmail.service;

import com.anz.dsc.goodmail.domain.Batch;
import reactor.bus.Event;
import reactor.fn.Consumer;

public interface MailScheduleService {

    void schedule(Batch batch);
}
