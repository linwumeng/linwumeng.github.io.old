package com.anz.dsc.goodmail.domain;

import com.anz.dsc.goodmail.domain.util.CustomDateTimeDeserializer;
import com.anz.dsc.goodmail.domain.util.CustomDateTimeSerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
import org.hibernate.annotations.Type;
import org.joda.time.DateTime;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * A Batch.
 */
@Entity
@Table(name = "BATCH")
@Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
public class Batch implements Serializable, Comparable<Batch> {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @NotNull
    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "start_time", nullable = false)
    private DateTime startTime;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "end_time", nullable = false)
    private DateTime endTime;

    @NotNull
    @Column(name = "number_of_received_mail", nullable = false)
    private Integer numberOfReceivedMail = 0;

    @Column(name = "number_of_processed_file")
    private Integer numberOfProcessedFile;

    @Column(name = "number_of_replied_mail")
    private Integer numberOfRepliedMail = 0;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "job_start_time", nullable = false)
    private DateTime jobStartTime;

    @Type(type = "org.jadira.usertype.dateandtime.joda.PersistentDateTime")
    @JsonSerialize(using = CustomDateTimeSerializer.class)
    @JsonDeserialize(using = CustomDateTimeDeserializer.class)
    @Column(name = "job_end_time", nullable = false)
    private DateTime jobEndTime;

    @Column(name = "number_of_transformed_file")
    private Integer numberOfTransformedFile;

    @Column(name = "number_of_transformed_byte")
    private Long numberOfTransformedByte;

    @ManyToMany
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "BATCH_FOLDER",
               joinColumns = @JoinColumn(name="batchs_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="folders_id", referencedColumnName="ID"))
    private Set<Folder> folders = new ConcurrentSkipListSet<>();

    @ManyToMany(cascade = CascadeType.ALL)
    @Cache(usage = CacheConcurrencyStrategy.NONSTRICT_READ_WRITE)
    @JoinTable(name = "BATCH_ITEM",
               joinColumns = @JoinColumn(name="batchs_id", referencedColumnName="ID"),
               inverseJoinColumns = @JoinColumn(name="items_id", referencedColumnName="ID"))
    private Set<Item> items = new ConcurrentSkipListSet<>();

    @Transient
    private AtomicInteger remains = new AtomicInteger();

    public int reduce(int i) {
        return remains.addAndGet(-i);
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public DateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(DateTime startTime) {
        this.startTime = startTime;
    }

    public DateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(DateTime endTime) {
        this.endTime = endTime;
    }

    public Integer getNumberOfReceivedMail() {
        return numberOfReceivedMail;
    }

    public void setNumberOfReceivedMail(Integer numberOfReceivedMail) {
        this.numberOfReceivedMail = numberOfReceivedMail;

        this.remains.set(this.numberOfReceivedMail);
    }

    public Integer getNumberOfProcessedFile() {
        return numberOfProcessedFile;
    }

    public void setNumberOfProcessedFile(Integer numberOfProcessedFile) {
        this.numberOfProcessedFile = numberOfProcessedFile;
    }

    public Integer getNumberOfRepliedMail() {
        return numberOfRepliedMail;
    }

    public void setNumberOfRepliedMail(Integer numberOfRepliedMail) {
        this.numberOfRepliedMail = numberOfRepliedMail;
    }

    public DateTime getJobStartTime() {
        return jobStartTime;
    }

    public void setJobStartTime(DateTime jobStartTime) {
        this.jobStartTime = jobStartTime;
    }

    public DateTime getJobEndTime() {
        return jobEndTime;
    }

    public void setJobEndTime(DateTime jobEndTime) {
        this.jobEndTime = jobEndTime;
    }

    public Integer getNumberOfTransformedFile() {
        return numberOfTransformedFile;
    }

    public void setNumberOfTransformedFile(Integer numberOfTransformedFile) {
        this.numberOfTransformedFile = numberOfTransformedFile;
    }

    public Long getNumberOfTransformedByte() {
        return numberOfTransformedByte;
    }

    public void setNumberOfTransformedByte(Long numberOfTransformedByte) {
        this.numberOfTransformedByte = numberOfTransformedByte;
    }

    public Set<Folder> getFolders() {
        return folders;
    }

    public void setFolders(Set<Folder> folders) {
        this.folders = folders;
    }

    public Set<Item> getItems() {
        return items;
    }

    public void setItems(Set<Item> items) {
        this.items = items;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Batch batch = (Batch) o;

        if ( ! Objects.equals(id, batch.id)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }

    @Override
    public String toString() {
        return "Batch{" +
                "id=" + id +
                ", startTime='" + startTime + "'" +
                ", endTime='" + endTime + "'" +
                ", numberOfReceivedMail='" + numberOfReceivedMail + "'" +
                ", numberOfProcessedFile='" + numberOfProcessedFile + "'" +
                ", numberOfRepliedMail='" + numberOfRepliedMail + "'" +
                ", jobStartTime='" + jobStartTime + "'" +
                ", jobEndTime='" + jobEndTime + "'" +
                ", numberOfTransformedFile='" + numberOfTransformedFile + "'" +
                ", numberOfTransformedByte='" + numberOfTransformedByte + "'" +
                ", items=\n"  + items.size() +
                '}';
    }

    public void addFolder(Folder f) {
        folders.add(f);
    }

    public void inc(int total) {
        this.numberOfReceivedMail += total;
    }

    public void addItem(Item item) {
        items.add(item);
    }

    @Override
    public int compareTo(Batch o) {
        if (null == o) {
            return 1;
        }

        DateTime t1 = this.startTime == null ? new DateTime(0) : this.startTime;
        DateTime t2 = this.startTime == null ? new DateTime(0) : o.startTime;
        if (!t1.equals(t2)) {
            return t1.compareTo(t2);
        }

        t1 = this.jobStartTime == null ? new DateTime(0) : this.jobStartTime;
        t2 = o.jobStartTime == null ? new DateTime(0) : o.jobStartTime;

        return t1.compareTo(t2);
    }
}
