package com.anz.dsc.goodmail.service;

public interface InboxService {

    void poll();

    void next();
}
