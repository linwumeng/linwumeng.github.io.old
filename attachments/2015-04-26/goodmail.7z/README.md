README for goodmail
==========================
