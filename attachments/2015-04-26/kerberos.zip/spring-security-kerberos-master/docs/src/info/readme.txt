SPRING SECURITY KERBEROS
------------------------
http://projects.spring.io/spring-security-kerberos/

1. INTRODUCTION

Spring Statemachine is a framework extension introducing state machine
concepts in a spring world.

2. RELEASE NOTES

This release comes with complete reference documentation. For further
details, consult the provided javadoc for specific packages and classes.

3. DISTRIBUTION JAR FILES

The Spring Statemachine jars files can be found in the 'dist' directory. 

4. GETTING STARTED

Please see the reference documentation.
Additionally the blog at http://blog.spring.io as well
as sections of interest in the reference documentation.

