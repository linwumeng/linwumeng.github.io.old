package cc.wdcy.infrastructure.mybatis;

import cc.wdcy.domain.oauth.OauthRepository;

/**
 * @author Shengzhao Li
 */
public interface OauthRepositoryMyBatis extends OauthRepository {
}