package cc.wdcy.infrastructure.mybatis;

import cc.wdcy.domain.user.UserRepository;

/**
 * @author Shengzhao Li
 */
public interface UserRepositoryMyBatis extends UserRepository {
}